"""GEE 未映射 API 的核心 Python/遥感算法实现。

仅保留数值计算：不含数据库注册、Web 接口或平台调用。NumPy 是必需依赖，
SciPy 和 scikit-image 仅在对应算法被调用时需要。
"""

from __future__ import annotations

from typing import Any, Callable, Optional

import numpy as np


def image_exp(image: np.ndarray) -> np.ndarray:
    """ee.Image.exp：逐像元计算 e^x。"""
    return np.exp(np.asarray(image))


def matrix_multiply(left: np.ndarray, right: np.ndarray) -> np.ndarray:
    """ee.Image.matrixMultiply：矩阵乘法。"""
    return np.matmul(left, right)


def random_image(shape: tuple[int, ...], seed: Optional[int] = None, distribution: str = 'uniform') -> np.ndarray:
    """ee.Image.random：创建可复现的均匀或标准正态随机栅格。"""
    generator = np.random.default_rng(seed)
    return generator.standard_normal(shape) if distribution == 'normal' else generator.random(shape)


def unit_scale(image: np.ndarray, low: float, high: float) -> np.ndarray:
    """ee.Image.unitScale：线性缩放 [low, high] 至 [0, 1]。"""
    if high == low:
        raise ValueError('low and high must be different')
    return (np.asarray(image) - low) / (high - low)


def reduce_image(image: np.ndarray, reducer: str | Callable[..., Any], axis: Optional[int] = None) -> Any:
    """ee.Image.reduce：平均、求和、极值、中位数、方差等归约。"""
    reducers = {
        'mean': np.mean, 'sum': np.sum, 'max': np.max, 'min': np.min,
        'median': np.median, 'std': np.std, 'var': np.var, 'count': np.count_nonzero,
    }
    function = reducers.get(reducer, np.mean) if isinstance(reducer, str) else reducer
    return function(image, axis=axis)


def reduce_neighborhood(image: np.ndarray, reducer: str = 'mean', kernel_size: int = 3) -> np.ndarray:
    """ee.Image.reduceNeighborhood：k×k 邻域均值/总和。"""
    from scipy.ndimage import uniform_filter
    local_mean = uniform_filter(np.asarray(image, dtype=float), size=kernel_size)
    if reducer == 'mean':
        return local_mean
    if reducer == 'sum':
        return local_mean * kernel_size ** 2
    raise ValueError("reducer must be 'mean' or 'sum'")


def connected_pixel_count(image: np.ndarray, max_size: int = 100, eight_connected: bool = True) -> np.ndarray:
    """ee.Image.connectedPixelCount：计算每个非零像元所在连通域的面积。"""
    from scipy.ndimage import label
    binary = np.asarray(image) != 0
    structure = np.ones((3, 3), dtype=int) if eight_connected else np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]])
    labels, region_count = label(binary, structure=structure)
    result = np.zeros(binary.shape, dtype=int)
    for region in range(1, region_count + 1):
        mask = labels == region
        result[mask] = min(int(mask.sum()), max_size)
    return result


def canny_edge_detector(image: np.ndarray, threshold: float = 0.5, sigma: float = 1.0) -> np.ndarray:
    """ee.Algorithms.CannyEdgeDetector；无 scikit-image 时回退 Sobel 阈值。"""
    try:
        from skimage.feature import canny
        return canny(image, sigma=sigma, low_threshold=threshold * 0.5, high_threshold=threshold)
    except ImportError:
        from scipy.ndimage import sobel
        dx, dy = sobel(image, axis=0), sobel(image, axis=1)
        return (np.hypot(dx, dy) > threshold).astype(float)


def terrain_products(dem: np.ndarray) -> dict[str, np.ndarray]:
    """ee.Terrain.products：用 Sobel 梯度估算坡度、坡向、简化山体阴影。"""
    from scipy.ndimage import sobel
    dx, dy = sobel(dem, axis=1), sobel(dem, axis=0)
    slope = np.degrees(np.arctan(np.hypot(dx, dy)))
    aspect = np.degrees(np.arctan2(dy, -dx))
    aspect = np.where(aspect < 0, aspect + 360, aspect)
    hillshade = np.cos(np.radians(45 - slope)) * np.cos(np.radians(45 - aspect))
    return {'slope': slope, 'aspect': aspect, 'hillshade': hillshade}


def consumers_accuracy(confusion_matrix: np.ndarray) -> np.ndarray:
    """ee.ConfusionMatrix.consumersAccuracy：按列计算对角线/列和。"""
    matrix = np.asarray(confusion_matrix, dtype=float)
    sums = matrix.sum(axis=0)
    return np.divide(np.diag(matrix), sums, out=np.zeros(matrix.shape[0]), where=sums != 0)
