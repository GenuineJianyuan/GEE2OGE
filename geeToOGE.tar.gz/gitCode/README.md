# GEE ↔ OGE 核心算法

这是从 GEE→OGE 工程中抽取的、可独立发布到 Git 的算法包。它**不包含** Flask 接口、网页、任务队列、SQLite 数据库、缓存、结果保存服务及 LLM HTTP 调用，只保留可以被其他程序直接复用的转换逻辑。

## 目录

```text
gitCode/
├── main.py                         # 命令行入口
├── dependency.md                   # 依赖与运行环境
├── core/
│   ├── analysis.py                 # GEE 静态解析与 API 识别
│   ├── mapping.py                  # 映射库加载与双向检索
│   ├── converter.py                # GEE→OGE / OGE→GEE 规则转换
│   └── native_algorithms.py        # Python 原生遥感与空间算法
└── data_resources/
    ├── source_code/                # 转换前 GEE 代码资源
    ├── converted_code/             # 转换后 OGE 代码资源
    └── mappings/                   # 轻量核心算子映射表
```

## 核心算法

1. **语义步骤拆分**：用 GEE 的单行注释切分工作流步骤，同时保留所有可执行代码。
2. **变量类型推断**：识别 `ee.Image`、`ee.ImageCollection`、`ee.Geometry` 等构造和链式赋值，解决 `image.select()` 这类实例调用的 API 归属问题。
3. **API 识别**：提取 `ee.*`、`Map.*`、`Export.*`、`print` 和类型确定的实例方法。
4. **映射匹配**：将识别 API 与 JSON 映射表匹配，计算匹配率并记录缺失项；支持一对一、一对多和原生 Python 三类实现。
5. **规则代码生成**：按映射类型生成 OGE `getProcess(...).execute(...)` 骨架，明确保留待补参数和待人工确认项。
6. **反向转换草稿**：扫描 OGE `getProcess` 调用并反查 GEE API，生成可审查的 GEE 转换草稿。
7. **遥感原生实现**：包含指数、矩阵乘法、单位缩放、统计归约、邻域统计、连通域像元数、Canny、DEM 地形因子及消费者精度。

## 快速开始

在 `gitCode` 目录下运行：

```bash
# 分析 GEE 脚本
python main.py analyze-gee data_resources/source_code/ndvi_calculator_gee.js

# GEE → OGE；生成的脚本是可审查的转换骨架
python main.py gee-to-oge data_resources/source_code/ndvi_calculator_gee.js -o output_oge.py

# OGE → GEE；生成反向映射草稿
python main.py oge-to-gee data_resources/converted_code/ndvi_calculator_oge.py -o output_gee.js
```

## 映射表扩展

在 `data_resources/mappings/core_operator_mappings.json` 中追加条目即可扩展映射。格式：

```json
{
  "gee_api": "ee.Image.normalizedDifference",
  "oge_apis": ["Coverage.subtract", "Coverage.add", "Coverage.divide"],
  "mapping_type": "one_to_many",
  "note": "(band1-band2)/(band1+band2)"
}
```

代码生成不会臆造数据集 ID、坐标系、空间分辨率或 OGE 算子参数；这些内容会以 TODO 或占位参数保留，供使用者审核补全。
