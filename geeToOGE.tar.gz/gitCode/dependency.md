# 依赖说明

## 基础环境

- Python 3.10 或更高版本
- 标准库：`argparse`、`json`、`pathlib`、`dataclasses`、`re`、`typing`

以下核心模块不需要数据库、Web 服务、Flask、Requests 或任何 LLM 服务：

- `core/analysis.py`
- `core/mapping.py`
- `core/converter.py`
- `main.py`

## 遥感算法依赖

`core/native_algorithms.py` 按函数需要以下第三方包：

| 依赖 | 用途 | 必需性 |
| --- | --- | --- |
| `numpy` | 像元数学、归约、随机栅格、精度计算 | 必需 |
| `scipy` | 邻域统计、连通域、Sobel 地形/边缘算法 | 使用对应函数时必需 |
| `scikit-image` | 完整 Canny 边缘检测 | 可选；未安装时自动使用 Sobel 回退 |

安装：

```bash
pip install numpy scipy scikit-image
```

## OGE 运行依赖

本仓库的转换器输出 OGE Python 脚本，但**不执行**这些脚本。因此核心算法包本身不需要安装 `oge`。若需要实际运行生成的 OGE 脚本，请在目标环境中按 OGE 平台文档安装并配置其 SDK、服务地址和数据目录。

## 数据与安全边界

- 样例映射表是核心、可审查的轻量映射集，不是完整 API 知识库。
- 样例代码不包含访问令牌、密钥或生产数据。
- 生成代码的 `TODO` 与 `...` 表示需要人工确认的参数，不能直接作为生产任务执行。
